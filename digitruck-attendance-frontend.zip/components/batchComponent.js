import React from 'react';
import { useRouter } from 'next/router';

const BatchComponent = ({ batches, hasError, region, loading }) => {
    const router = useRouter();
    return (
        <>
            <div className="font-semibold text-xl pl-5">{region.regionName}</div>
            <div>
                {loading && <p>Loading...</p>}
                {!loading && (
                    <>
                        {hasError && <div>Error - Retrieving Information</div>}
                        {!hasError && batches.length === 0 && <div>No Bathces in this region</div>}
                        {!hasError &&
                            batches.length > 0 &&
                            batches.map((batch) => (
                                <div
                                    className="px-8 py-14 mt-8 flex items-center justify-between rounded-3xl drop-shadow-md bg-black/5 w-full h-14 cursor-pointer hover:shadow-xl transition ease-in-out duration-300"
                                    key={batch.name}
                                    onClick={() => router.push({ pathname: `/region/${region.regionName}/${batch.name}`, query: { region: region.regionName, batch: batch.name } }, `/region/${region.regionName}/${batch.name}`)}
                                >
                                    <div className="">{batch.name}</div>
                                    {/* <div className="">{batch.completed.toString()}</div> */}
                                </div>
                            ))}
                    </>
                )}
            </div>
        </>
    );
};

export default BatchComponent;
