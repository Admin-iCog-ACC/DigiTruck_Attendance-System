import { useRouter } from 'next/router';
import Cards from '../assets/cards.json';
import React, { useContext, useEffect, useState } from 'react';

const CardComponent = ({ hasError, specificStarData }) => {
    const router = useRouter();

    return (
        <div className="p-10 bg-[#f1fcfe] h-[100vh]">
            <div className="px-8 py-14 mt-24 rounded-3xl drop-shadow-md bg-white">
                {/* <TableDemo /> */}
                <div>
                    {hasError && <h1>Error - please try another parameter</h1>}
                    {!hasError && router.isFallback && <h1>Loading...</h1>}
                    {!hasError && !router.isFallback && (
                        <div>
                            <h1>{specificStarData.name}</h1>
                            <p>{specificStarData.description}</p>
                            <a href={specificStarData.link}>More Information here (link)</a>
                        </div>
                    )}
                </div>{' '}
            </div>
        </div>
    );
};

export default CardComponent;
