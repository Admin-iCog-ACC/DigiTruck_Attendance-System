import { useRouter } from 'next/router';
import React, { useContext, useEffect, useState } from 'react';
import Cards from '../assets/cards.json';
import RegionComponent from './regionsComponent';

const HomePage = () => {
    const [regions, setregions] = useState([]);
    const [regionCount, setregionCount] = useState(0);
    useEffect(() => {
        // setcards(Cards.data);
        // console.log(Cards.data);
        const fetchRegions = async () => {
            try {
                const res = await fetch(`http://localhost:9000/api/v1/regions/`);
                const data = await res.json();
                // console.log(data);
                setregions(data.regions);
                setregionCount(data.total);
            } catch (err) {
                console.log(err);
            }
        };

        fetchRegions();
    }, []);
    // const router = useRouter();

    return (
        <>
            <div className="font-semibold text-xl pl-5">Regions</div>
            <div className="grid gap-x-10 gap-y-0 grid-cols-3 place-items-center">
                {regions === null && <p>Loading...</p>}
                {regions !== null && regions.map((data) => <RegionComponent key={data.regionName} region={data} />)}
            </div>
        </>
    );
};

export default HomePage;
