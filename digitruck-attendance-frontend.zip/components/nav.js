import { useEffect, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/router';

function Nav() {
    // const [scrollState, setScrollState] = useState(false);
    const router = useRouter();
    //   const [isOpen, setIsOpen] = useRecoilState(navModalState);
    // useEffect(() => {
    //     const changeNavBackground = () => {
    //         setScrollState(window.scrollY > 65);
    //     };
    //     window.addEventListener('scroll', changeNavBackground);
    //     return () => window.removeEventListener('scroll', changeNavBackground);
    // }, [scrollState]);

    return (
        <div className={'w-full fixed top-0 z-10 h-24  bg-white shadow-lg'}>
            <div className="max-w-[1225px] xl:mx-auto mx-5 flex justify-between items-center ">
                <div className={'h-24 w-1/2 relative  flex items-start '} >
                    <div className='hover:cursor-pointer flex items-center' onClick={()=>router.replace("/home")}>
                    <Image src="/icon-icog.png" width={60} height={100} objectFit="contain" alt="logo" />
                    <span className="ml-5 font-semibold">Digitruck Attendance</span>
                    </div>
                    
                </div>
                <div className="lg:flex text-base font-semibold hidden space-x-10 items-center w-1/2 justify-end">
                    <span className="mr-1 cursor-pointer link link-underline link-underline-black" onClick={()=>router.replace("/")}>Logout</span>
                </div>
            </div>
        </div>
    );
}

export default Nav;
