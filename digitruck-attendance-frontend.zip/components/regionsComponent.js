import React from 'react';
import { useRouter } from 'next/router';

const RegionComponent = ({ region }) => {
    const router = useRouter();
    return (
        <div className="px-8 py-14 mt-8 rounded-3xl drop-shadow-md bg-white w-72 h-80 cursor-pointer hover:shadow-xl transition ease-in-out duration-300" onClick={() => router.push(`/region/${region.regionName}`)}>
            <div className="h-3/4 w-full bg-white">
                <p>{region.regionName}</p>
                <p className='mt-2'>{region.description}</p>
            </div>
            <div className="h-28 w-72 bg-[#1ba3b8] -mx-8 rounded-br-3xl rounded-bl-3xl"></div>
        </div>
    );
};

export default RegionComponent;
